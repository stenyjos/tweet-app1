export const environment = {
  production: true,
  servername: ''
};
